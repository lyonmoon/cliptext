<div class="row footer">
	<p>A project by <a href="http://twitter.com/davidadamojr" target="_blank">@davidadamojr</a><br/><br/><a href="privacy.php" target="_blank">Privacy Policy</a></p>
</div>